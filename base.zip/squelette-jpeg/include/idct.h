/* Projet C - Sujet JPEG */
#ifndef __IDCT_H
#define __IDCT_H

#include <stdint.h>

extern void IDCT(int32_t *input, uint8_t *output);

#endif
