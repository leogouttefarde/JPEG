/* Projet C - Sujet JPEG */
#ifndef __SKIP_SEGMENT_H
#define __SKIP_SEGMENT_H
#include <stdio.h>
extern void skip_segment(FILE *image);

#endif
