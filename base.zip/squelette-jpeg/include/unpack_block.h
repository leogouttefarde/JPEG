/* Projet C - Sujet JPEG */
#ifndef __UNPACK_BLOCK_H
#define __UNPACK_BLOCK_H

#include "jpeg.h"
#include <stdint.h>
#include <stdio.h>

extern void unpack_block(FILE *image, scan_desc_t *scan_desc,
			 uint32_t index, int32_t T[64]);


#endif
