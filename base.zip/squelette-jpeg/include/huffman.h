/* Projet C - Sujet JPEG */
#ifndef __HUFFMAN_H
#define __HUFFMAN_H

#include "jpeg.h"
#include <stdint.h>
#include <stdio.h>

extern void free_huffman_tables(huff_table_t *root);

extern int load_huffman_table(FILE *image, huff_table_t *ht);


#endif
