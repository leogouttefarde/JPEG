/* Projet C - Sujet JPEG */
#ifndef __TIFF_H__
#define __TIFF_H__

#include <stdint.h>
#include <stdio.h>

/*  Screen_init initializes the screen for JPEG visualization
 *  Parameters are :
 *  	width : width of the screen (image) in pixels
 *  	height : height of the screen (image) in pixels
 */

extern int init_tiff_file ( FILE * tifffile , uint32_t width ,
                                uint32_t length , uint32_t MCU_height ) ;



/* screen_exit cleanly close the screen
*/

extern int close_tiff_file(FILE *tifffile);

extern void write_tiff_file ( FILE * tifffile , uint32_t w, uint32_t * image );

extern void finalize_tiff_file(FILE *tiff_file);


#endif
