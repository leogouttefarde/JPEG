
#include "conv.h"


uint32_t truncate(int32_t s)
{
        if (s > 255)
                s = 255;

        else if (s < 0)
                s = 0;

        return (uint32_t)s;
}

void YCbCr_to_ARGB(uint8_t  *YCbCr_MCU[3], uint32_t *RGB_MCU,
                   uint32_t nb_block_H, uint32_t nb_block_V)
{
        const uint32_t SIZE = 8*nb_block_H * 8*nb_block_V;

        uint8_t *Y = YCbCr_MCU[0];
        uint8_t *Cb = YCbCr_MCU[1];
        uint8_t *Cr = YCbCr_MCU[2];
        int32_t R, G, B;

        for (uint32_t i = 0; i < SIZE; ++i) {

                /* Conversion moins précise */
                // R = Y[i] + 1.402 * (Cr[i] - 128);
                // G = Y[i] - 0.34414 * (Cb[i] - 128) - 0.71414 * (Cr[i] - 128);
                // B = Y[i] + 1.772 * (Cb[i] - 128);

                /* Conversion plus précise */
                R = Y[i] - 0.0009267 * (Cb[i] - 128) + 1.4016868 * (Cr[i] - 128);
                G = Y[i] - 0.3436954 * (Cb[i] - 128) - 0.7141690 * (Cr[i] - 128);
                B = Y[i] + 1.7721604 * (Cb[i] - 128) + 0.0009902 * (Cr[i] - 128);


                RGB_MCU[i] = truncate(R) << 16 | truncate(G) << 8 | truncate(B);
        }
}

