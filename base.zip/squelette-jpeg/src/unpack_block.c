
#include "unpack_block.h"
#include "common.h"


int8_t fetch_bit(FILE *file, scan_desc_t *scan_desc)
{
        uint8_t bit;
        uint8_t byte = scan_desc->window;
        //assert(file && scan_desc);

        if (scan_desc->bit_count == 0) {

                uint8_t last = byte;
                fread(&byte, 1, 1, file);

                if (last == 0xFF) {
                        if (byte != 0x00)
                                printf("Error : corrupted JPEG file\n");

                        fread(&byte, 1, 1, file);
                }

                scan_desc->window = byte;
                scan_desc->bit_count = 8;
        }

        bit = 1 & (byte >> --scan_desc->bit_count);

        return (int8_t)bit;
}

int8_t extract_symbol(FILE *file, scan_desc_t *scan_desc, huff_table_t *ht)
{
        int8_t bit;
        int8_t result = 0;

        while (ht && !ht->is_elt) {
                bit = fetch_bit(file, scan_desc);

                if (bit)
                        ht = ht->right;

                else
                        ht = ht->left;
        }

        if (ht != NULL)
            result = ht->value;

        return result;
}

int16_t extract_dpcm(FILE *file, scan_desc_t *scan_desc, uint8_t nb_bits)
{
        bool negative = false;
        int16_t value = 0;

        if (nb_bits > 0) {
                value = fetch_bit(file, scan_desc);

                if (value == 0)
                        negative = true;

                for (uint8_t k = 1; k < nb_bits; ++k)
                        value = (value << 1) | fetch_bit(file, scan_desc);

                if (negative)
                        value = -1 * ((1 << nb_bits) - 1 - value);
        }

        return value;
}

void unpack_block(FILE *image, scan_desc_t *scan_desc,
                  uint32_t index, int32_t T[64])
{
        const uint8_t BLOCK_SIZE = 8 * 8;
        int8_t nb_bits, zeros, symbol;
        uint8_t n = 0;
        int16_t diff;

        huff_table_t *AC = scan_desc->table[1][index];
        huff_table_t *DC = scan_desc->table[0][index];

        if (AC == NULL || DC == NULL)
                // Error
                return;


        nb_bits = extract_symbol(image, scan_desc, DC);
        diff = extract_dpcm(image, scan_desc, nb_bits);

        T[n] = scan_desc->pred[index] + diff;
        scan_desc->pred[index] = T[n];
        n++;


        while (n < BLOCK_SIZE) {
                symbol = extract_symbol(image, scan_desc, AC);

                switch (symbol) {
                case 0xF0:
                        for (uint8_t i = 0; i < 16; i++)
                                T[n + i] = 0;

                        n += 16;
                        break;

                case 0x00:
                        for (; n < BLOCK_SIZE; n++)
                                T[n] = 0;
                        break;

                default:
                        nb_bits = symbol & 0xF;
                        zeros = ((uint8_t)symbol) >> 4;

                        for (uint8_t i = 0; i < zeros; i++)
                                T[n + i] = 0;

                        n += zeros;

                        T[n++] = extract_dpcm(image, scan_desc, nb_bits);
                }
        }
}

