
#include "tiff.h"

/*  Screen_init initializes the screen for JPEG visualization
 *  Parameters are :
 *      width : width of the screen (image) in pixels
 *      height : height of the screen (image) in pixels
 */

int init_tiff_file(FILE *tiff_file, uint32_t width, uint32_t length, uint32_t MCU_height)
{
        if (tiff_file == NULL)  return -1;

        


        return 0;
}

/* screen_exit cleanly close the screen
*/
int close_tiff_file(FILE *tiff_file)
{
        fclose(tiff_file);

        return 0;
}

void write_tiff_file (FILE *tiff_file, uint32_t w, uint32_t *image)
{

}

void finalize_tiff_file(FILE *tiff_file)
{

}


