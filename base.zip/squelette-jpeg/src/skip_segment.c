
#include "skip_segment.h"
#include "common.h"

void skip_segment(FILE *image)
{
        char buf[2];
        uint16_t size;

        fread(buf, 0, sizeof(buf), image);
        size = (buf[0] << 8) + buf[1];

        fseek(image, size - sizeof(buf), SEEK_CUR);
}

