
#include "huffman.h"
#include "common.h"


void free_huffman_tables(huff_table_t *root)
{
        if (root != NULL) {
                free_huffman_tables(root->left);
                free_huffman_tables(root->right);

                SAFE_FREE(root);
        }
}

huff_table_t* create_node(uint16_t code, int8_t value, int8_t is_elt, huff_table_t *parent)
{
        huff_table_t *node = malloc(sizeof(huff_table_t));

        if (node != NULL) {
                node->code = code;
                node->value = value;
                node->is_elt = is_elt;
                node->parent = parent;
                node->left = NULL;
                node->right = NULL;
        }

        return node;
}

int8_t add_huffman_code(int8_t value, uint8_t code_size, huff_table_t *parent)
{
        int8_t error = 0;
        uint16_t code = parent->code << 1;

        if (parent->is_elt)
                error = 1;

        else if (code_size == 0) {
                if (parent->left == NULL)
                        parent->left = create_node(code, value, 1, parent);

                else if (parent->right == NULL)
                        parent->right = create_node(code + 1, value, 1, parent);

                else
                        error = -1;
        }
        else {
                if (parent->left == NULL)
                        parent->left = create_node(code, 0, 0, parent);

                error = add_huffman_code(value, code_size - 1, parent->left);

                if (error) {
                        if (parent->right == NULL)
                                parent->right = create_node(code + 1, 0, 0, parent);

                        error = add_huffman_code(value, code_size - 1, parent->right);
                }
        }

        return error;
}

int load_huffman_table(FILE *image, huff_table_t *ht)
{
        uint8_t code_sizes[16];
        uint16_t nb_codes = 0;
        int32_t size_read = 0;

        if (ht == NULL)
                return -1;

        memset(ht, 0, sizeof(huff_table_t));
        size_read += fread(code_sizes, 1, sizeof(code_sizes), image);

        for (uint8_t i = 0; i < sizeof(code_sizes); ++i)
                nb_codes += code_sizes[i];

        /* There must be less than 256 different codes */
        if (nb_codes >= 256)
                return -2;

        int8_t values[nb_codes];
        size_read += fread(values, 1, nb_codes, image);

        uint16_t index = 0;
        for (uint8_t i = 0; i < sizeof(code_sizes); ++i) {

                for (uint8_t j = 0; j < code_sizes[i]; ++j)
                        add_huffman_code(values[index + j], i, ht);

                index += code_sizes[i];
        }

        return size_read;
}

