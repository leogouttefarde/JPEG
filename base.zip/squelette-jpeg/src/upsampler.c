
#include "upsampler.h"


/*
 * Optimized equations :
 *      us = h + v * 8 * nb_block_H + i * h_factor + j * v_factor * 8 * nb_block_H + x * 8 * h_factor + y * v_factor * 8 * nb_block_H * 8;
 *      ds = i + j * 8 + x * 64 + y * 64 * nb_block_H / h_factor;
 */
// memcpy
static inline void upsample_pixel(uint8_t *MCU_ds, uint8_t *MCU_us,
                    uint32_t ds, uint32_t us_index,
                    uint8_t h_factor, uint8_t v_factor,
                    uint16_t nb_block_H)
{
        const uint32_t LINE = 8 * nb_block_H;
        uint32_t us;

        for (uint16_t v = 0; v < v_factor; ++v) {

                us = us_index;

                for (uint16_t h = 0; h < h_factor; ++h) {

                        MCU_us[us++] = MCU_ds[ds];
                }

                us_index += LINE;
        }
}

static inline void upsample_block(uint8_t *MCU_ds, uint8_t *MCU_us,
                    uint32_t ds_index, uint32_t us_index,
                    uint8_t h_factor, uint8_t v_factor,
                    uint16_t nb_block_H)
{
        const uint32_t LINE = v_factor * 8 * nb_block_H;
        uint32_t ds, us;

        for (uint16_t j = 0; j < 8; ++j) {

                ds = ds_index;
                us = us_index;

                for (uint16_t i = 0; i < 8; ++i) {

                        upsample_pixel(MCU_ds, MCU_us, ds++, us, h_factor, v_factor, nb_block_H);
                        us += h_factor;
                }

                ds_index += 8;
                us_index += LINE;
        }
}


void upsampler(uint8_t *MCU_ds, uint8_t *MCU_us,
               uint8_t h_factor, uint8_t v_factor,
               uint16_t nb_block_H, uint16_t nb_block_V)
{
        const uint16_t nb_block_V_ds = nb_block_V / v_factor;
        const uint16_t nb_block_H_ds = nb_block_H / h_factor;

        /* Optimizations */
        const uint32_t DS_LINE = 64 * nb_block_H_ds;
        const uint32_t US_LINE = v_factor * 64 * nb_block_H;
        const uint32_t H_SIZE = 8 * h_factor;
        uint32_t ds, ds_index = 0;
        uint32_t us, us_index = 0;


        for (uint16_t y = 0; y < nb_block_V_ds; ++y) {

                ds = ds_index;
                us = us_index;

                for (uint16_t x = 0; x < nb_block_H_ds; ++x) {

                        upsample_block(MCU_ds, MCU_us, ds, us, h_factor, v_factor, nb_block_H);

                        ds += 64;
                        us += H_SIZE;
                }

                ds_index += DS_LINE;
                us_index += US_LINE;
        }
}


